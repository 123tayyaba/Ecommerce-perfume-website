before running the code create a database with a name `finalretail` then 
copy paste the code written in retailsystem(1).sql in the sql colum of the database
